import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Login | AI Test & Learning Platform",
  description: "Login to access personalized learning features",
} 